[Blackwell Convergence (GOG.com)](https://steamunlocked.net/626511-blackwell-convergence-free-download/)</br>
Revision 1 (2024.7.14)</br>
</br>
​번역: 브리티쉬(2024.7.14)</br>
스크립트, 디버깅, 변환: 브리티쉬</br>
</br>
주의사항</br>
이 번역 데이터는 Blackwell Convergence (GOG.com) 버전에 사용해야 합니다.</br>
</br>
</br>
한글 패치 설치 방법</br>
1. 제공된 파일들 (Korean.tra, game28.dta etc)을 게임 파일이 있는 폴더에 복사합니다.</br>
2. ScummVM 2.8.0pre 이상 AGS Extened Bitmap Font 적용된 버전에서 "게임 추가(A)..." 버튼을 눌러 게임을 등록합니다.</br>
3. 게임 옵션 - 게임의 언어를 "Korean"으로 설정하고 확인 버튼을 누릅니다.</br>
4. "시작(S)" 버튼을 눌러 게임을 시작합니다.</br>

